Select COUNT(*) as bon_nom
from Espece
where nom_scientifique = :nom_scientifique;