Select COUNT(*) as bon_enclos
from Enclos
where n_enclos = :n_enclos;