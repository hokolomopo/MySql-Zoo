<?php include 'overlay.php' ?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="UTF-8">

<style>
<?php style_fond() ?>
</style>

</head>

<body>

<?php 
corps_fond(); 
debut_main();
?>

    <h2 align="center">Super Zoo of the DOOM</h2>

<?php fin_main() ?>

</body>
</html>


