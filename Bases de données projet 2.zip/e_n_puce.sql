Select n_puce
from Animal
where nom_scientifique = :nom_scientifique
order by n_puce;